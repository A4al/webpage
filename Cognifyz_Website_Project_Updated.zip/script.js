
document.addEventListener("DOMContentLoaded", function () {
  window.changeBackground = function () {
    document.body.style.backgroundColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
  };

  document.getElementById("user-form").addEventListener("submit", function (e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    let msg = "";

    if (!name || !email) {
      msg = "All fields are required!";
    } else if (!email.includes("@")) {
      msg = "Enter a valid email address!";
    } else {
      msg = "Form submitted successfully!";
      document.getElementById("user-form").reset();
    }
    document.getElementById("form-msg").textContent = msg;
  });

  fetch("https://jsonplaceholder.typicode.com/users")
    .then(response => response.json())
    .then(data => {
      const container = document.getElementById("api-data");
      container.innerHTML += "<ul class='list-group'>";
      data.slice(0, 5).forEach(user => {
        container.innerHTML += `<li class='list-group-item'>${user.name} - ${user.email}</li>`;
      });
      container.innerHTML += "</ul>";
    });
});
